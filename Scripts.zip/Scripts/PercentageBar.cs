using UnityEngine;
using UnityEngine.UI;

public class PercentageBar : MonoBehaviour
{
    public Image fillImage;

    // Bar� g�ncelleyen ana metot
    public void UpdateBar(float current, float max)
    {
        if (max <= 0)
        {
            fillImage.fillAmount = 0;
            return;
        }

        // �lerleme oran�n� hesapla
        float progress = current / max;

        // Image bile�eninin fillAmount de�erini ayarla
        if (fillImage != null)
        {
            fillImage.fillAmount = progress;
        }
    }
}