using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;

public class PartInfoManager : MonoBehaviour
{
    [Header("UI Elemanlar�")]
    public GameObject infoPanel;
    public TextMeshProUGUI panelPartNameText;
    public Image partImage;
    public TextMeshProUGUI contentTitleText;
    public TextMeshProUGUI contentDescriptionText;

    [Header("Buton Metinleri")]
    public string whatIsItTitle = "Nedir?";
    public string purposeTitle = "Amac�?";
    public string howToChooseTitle = "Nas�l Se�ilir?";

    private DronePartData currentPartData;

    void Start()
    {
        // Oyun ba�lad���nda paneli gizle
        infoPanel.SetActive(false);
    }

    // Ana ekrandaki par�a butonlar� bu metodu �a��racak
    public void ShowInfoPanel(DronePartData partData)
    {
        currentPartData = partData;

        // Paneli g�r�n�r yap
        infoPanel.SetActive(true);

        // Panelin temel bilgilerini doldur
        panelPartNameText.text = partData.partName;

        if (partData.partImage != null)
        {
            partImage.sprite = partData.partImage;
            partImage.gameObject.SetActive(true);
        }
        else
        {
            partImage.gameObject.SetActive(false);
        }

        // Varsay�lan olarak "Nedir?" k�sm�n� g�ster
        ShowWhatIsIt();
    }

    // "Nedir?" butonuna bas�ld���nda
    public void ShowWhatIsIt()
    {
        if (currentPartData != null)
        {
            contentTitleText.text = whatIsItTitle;
            contentDescriptionText.text = currentPartData.whatIsIt;
        }
    }

    // "Amac�?" butonuna bas�ld���nda
    public void ShowPurpose()
    {
        if (currentPartData != null)
        {
            contentTitleText.text = purposeTitle;
            contentDescriptionText.text = currentPartData.purpose;
        }
    }

    // "Nas�l Se�ilir?" butonuna bas�ld���nda
    public void ShowHowToChoose()
    {
        if (currentPartData != null)
        {
            contentTitleText.text = howToChooseTitle;
            contentDescriptionText.text = currentPartData.howToChoose;
        }
    }

    // Paneli kapatmak i�in
    public void HideInfoPanel()
    {
        infoPanel.SetActive(false);
        currentPartData = null;
    }
}