using UnityEngine;

[CreateAssetMenu(fileName = "NewDronePartData", menuName = "Drone Info/Drone Part Data")]
public class DronePartData : ScriptableObject
{
    public string partName;
    public Sprite partImage;
    [TextArea(5, 10)]
    public string whatIsIt;
    [TextArea(5, 10)]
    public string purpose;
    [TextArea(5, 10)]
    public string howToChoose;
}