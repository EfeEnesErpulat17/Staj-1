using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class DronePartPanelManager : MonoBehaviour
{
    // Bu panele ait veri
    public DronePartData partData;

    // Ba�lanacak UI elemanlar�
    public TextMeshProUGUI panelTitleText;
    public Image partImage;
    public TextMeshProUGUI contentTitleText;
    public TextMeshProUGUI contentDescriptionText;

    private void OnEnable()
    {
        // Panel a��ld���nda bu metot �al���r. Varsay�lan olarak Nedir? k�sm�n� g�sterir.
        if (partData != null)
        {
            panelTitleText.text = partData.partName;

            if (partData.partImage != null)
            {
                partImage.sprite = partData.partImage;
                partImage.gameObject.SetActive(true);
            }
            else
            {
                partImage.gameObject.SetActive(false);
            }

            ShowWhatIsIt();
        }
    }

    // Nedir? butonuna bas�ld���nda �al���r
    public void ShowWhatIsIt()
    {
        contentTitleText.text = "Nedir?";
        contentDescriptionText.text = partData.whatIsIt;
    }

    // Amac�? butonuna bas�ld���nda �al���r
    public void ShowPurpose()
    {
        contentTitleText.text = "Amac�?";
        contentDescriptionText.text = partData.purpose;
    }

    // Nas�l Se�ilir? butonuna bas�ld���nda �al���r
    public void ShowHowToChoose()
    {
        contentTitleText.text = "Nas�l Se�ilir?";
        contentDescriptionText.text = partData.howToChoose;
    }
}