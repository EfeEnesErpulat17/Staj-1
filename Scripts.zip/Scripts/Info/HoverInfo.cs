using UnityEngine;
using UnityEngine.EventSystems;
using TMPro; // TextMeshPro kullanaca��m�z i�in bu k�t�phaneyi ekliyoruz

public class HoverInfo : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    // Hangi TextMeshPro objesinin g�ncellenece�ini buraya s�r�kleyip b�rak�n
    public TextMeshProUGUI infoTextObject;

    // Fare butona geldi�inde hangi metnin g�sterilece�ini buraya yaz�n
    public string infoText;

    // Fare butona girdi�inde bu fonksiyon �al���r
    public void OnPointerEnter(PointerEventData eventData)
    {
        if (infoTextObject != null)
        {
            infoTextObject.text = infoText;
        }
    }

    // Fare butondan ��kt���nda bu fonksiyon �al���r
    public void OnPointerExit(PointerEventData eventData)
    {
        if (infoTextObject != null)
        {
            infoTextObject.text = ""; // Metni bo�alt�r
        }
    }
}