using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Button), typeof(AudioSource))]
public class SoundManager : MonoBehaviour
{
    private AudioSource audioSource;

    // Inspector'dan atayaca��n�z ses dosyas�
    public AudioClip buttonClip;

    void Awake()
    {
        audioSource = GetComponent<AudioSource>();
        if (audioSource == null)
        {
            Debug.LogError("Bu butonda AudioSource bile�eni bulunamad�.");
        }
    }

    public void PlayButtonSound()
    {
        if (audioSource != null && buttonClip != null)
        {
            audioSource.PlayOneShot(buttonClip);
        }
    }
}