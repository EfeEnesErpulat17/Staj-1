using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;
using System.Linq;

// QuizQuestion s�n�f�, her bir sorunun verilerini tutar.
// Zaten sizde mevcut oldu�u i�in eklemeniz gerekmiyor.
// [System.Serializable]
// public class QuizQuestion
// {
//     public Sprite questionImage;
//     [TextArea(3, 5)]
//     public string questionText;
//     public string correctAnswer;
//     public List<string> incorrectAnswers;
// }

public class QuizGameplayManager : MonoBehaviour
{
    [Header("UI Elemanlar�")]
    public TextMeshProUGUI questionTextUI;
    public TextMeshProUGUI[] answerTextsUI;
    public Button[] answerButtons;
    public TextMeshProUGUI scoreTextUI;
    public TextMeshProUGUI questionNumberTextUI;

    // Yeni: Resimli buton ve panel i�in de�i�kenler
    public Button imageButton;
    public GameObject imagePanel;
    public Image panelImageComponent;
    public Button panelCloseButton;

    // YEN�: Ses i�in de�i�kenler
    [Header("Ses Ayarlar�")]
    public AudioClip correctSound;
    public AudioClip wrongSound;
    private AudioSource audioSource;

    [Header("Quiz Veri Havuzu")]
    public List<QuizQuestion> allQuestions;
    private List<QuizQuestion> selectedQuestions;
    private int score = 0;
    private int questionsAnswered = 0;
    private const int TOTAL_QUESTIONS_IN_QUIZ = 10;

    void Start()
    {
        // YEN�: AudioSource bile�enini al
        audioSource = GetComponent<AudioSource>();
        if (audioSource == null)
        {
            Debug.LogError("Bu objede AudioSource bile�eni bulunamad�!", this);
        }

        selectedQuestions = GetRandomQuestions(TOTAL_QUESTIONS_IN_QUIZ);

        score = 0;
        questionsAnswered = 0;
        UpdateScoreText();
        DisplayQuestion();

        if (panelCloseButton != null)
        {
            panelCloseButton.onClick.AddListener(CloseImagePanel);
        }

        if (imagePanel != null)
        {
            imagePanel.SetActive(false);
        }
    }

    void UpdateScoreText()
    {
        scoreTextUI.text = "Score: " + score;
    }

    // Cevap kontrol�, art�k metin kar��la�t�rmas� yap�yor
    public void AnswerSelected(int answerIndex)
    {
        if (questionsAnswered >= selectedQuestions.Count) return;

        string selectedAnswerText = answerTextsUI[answerIndex].text;
        string currentCorrectAnswerText = selectedQuestions[questionsAnswered].correctAnswer;

        // YEN�: Cevaba g�re farkl� sesleri �al
        if (selectedAnswerText == currentCorrectAnswerText)
        {
            score += 10;
            if (audioSource != null && correctSound != null)
            {
                audioSource.PlayOneShot(correctSound);
            }
        }
        else
        {
            score -= 5;
            if (audioSource != null && wrongSound != null)
            {
                audioSource.PlayOneShot(wrongSound);
            }
        }

        UpdateScoreText();
        questionsAnswered++;

        if (questionsAnswered >= TOTAL_QUESTIONS_IN_QUIZ)
        {
            PlayerPrefs.SetInt("PlayerScore", score);
            SceneManager.LoadScene("EndGameScene");
        }
        else
        {
            DisplayQuestion();
        }
    }

    void DisplayQuestion()
    {
        if (questionsAnswered >= selectedQuestions.Count) return;

        QuizQuestion currentQuestion = selectedQuestions[questionsAnswered];

        questionNumberTextUI.text = "Question " + (questionsAnswered + 1);

        if (imageButton != null)
        {
            if (currentQuestion.questionImage != null)
            {
                imageButton.gameObject.SetActive(true);
                imageButton.GetComponent<Image>().sprite = currentQuestion.questionImage;
                imageButton.onClick.RemoveAllListeners();
                imageButton.onClick.AddListener(OpenImagePanel);
            }
            else
            {
                imageButton.gameObject.SetActive(false);
            }
        }

        questionTextUI.text = currentQuestion.questionText;

        List<string> answerOptions = new List<string>();
        answerOptions.Add(currentQuestion.correctAnswer);
        answerOptions.AddRange(currentQuestion.incorrectAnswers);
        ShuffleList(answerOptions);

        for (int i = 0; i < answerButtons.Length; i++)
        {
            if (i < answerOptions.Count)
            {
                answerButtons[i].gameObject.SetActive(true);
                answerTextsUI[i].text = answerOptions[i];
                int tempIndex = i;
                answerButtons[i].onClick.RemoveAllListeners();
                answerButtons[i].onClick.AddListener(() => AnswerSelected(tempIndex));
            }
            else
            {
                answerButtons[i].gameObject.SetActive(false);
            }
        }
    }

    public void OpenImagePanel()
    {
        if (imagePanel != null && panelImageComponent != null && imageButton != null)
        {
            imagePanel.SetActive(true);
            panelImageComponent.sprite = imageButton.GetComponent<Image>().sprite;
        }
    }

    public void CloseImagePanel()
    {
        if (imagePanel != null)
        {
            imagePanel.SetActive(false);
        }
    }

    List<QuizQuestion> GetRandomQuestions(int count)
    {
        List<QuizQuestion> questionPool = new List<QuizQuestion>(allQuestions);
        ShuffleList(questionPool);
        return questionPool.Take(count).ToList();
    }

    void ShuffleList<T>(List<T> list)
    {
        for (int i = 0; i < list.Count; i++)
        {
            T temp = list[i];
            int randomIndex = Random.Range(i, list.Count);
            list[i] = list[randomIndex];
            list[randomIndex] = temp;
        }
    }
}