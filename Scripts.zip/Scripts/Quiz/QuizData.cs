using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class QuizQuestion
{
    public Sprite questionImage;
    [TextArea(3, 5)]
    public string questionText;
    public string correctAnswer;
    public List<string> incorrectAnswers;
}