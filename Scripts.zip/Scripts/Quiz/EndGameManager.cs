using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;
using System.Collections.Generic;
using System.Linq;

public class EndGameManager : MonoBehaviour
{
    public TextMeshProUGUI scoreText;
    public TMP_InputField nameInput;
    public Button saveButton;
    // Butonun metin bile�enine eri�mek i�in yeni de�i�ken
    public TextMeshProUGUI saveButtonText;

    private const string SCOREBOARD_KEY = "QuizScoreboard";
    private const string SEPARATOR = " - ";

    void Start()
    {
        int finalScore = PlayerPrefs.GetInt("PlayerScore", 0);
        scoreText.text = "Score: " + finalScore;
    }

    public void SaveScore()
    {
        string playerName = nameInput.text;
        if (string.IsNullOrEmpty(playerName))
        {
            playerName = "Anonim";
        }

        string newScoreEntry = playerName + SEPARATOR + PlayerPrefs.GetInt("PlayerScore", 0);

        string scoreboardData = PlayerPrefs.GetString(SCOREBOARD_KEY, "");

        List<string> scores = scoreboardData
                                .Split('\n')
                                .Where(s => !string.IsNullOrWhiteSpace(s) && s.Contains(SEPARATOR))
                                .ToList();

        scores.Add(newScoreEntry);

        var sortedScores = scores
            .Select((scoreEntry, index) => new { ScoreEntry = scoreEntry, Index = index })
            .OrderByDescending(x => int.Parse(x.ScoreEntry.Split(SEPARATOR)[1].Trim()))
            .ThenByDescending(x => x.Index)
            .Select(x => x.ScoreEntry)
            .ToList();

        string updatedScoreboard = string.Join("\n", sortedScores.Take(5));
        PlayerPrefs.SetString(SCOREBOARD_KEY, updatedScoreboard);

        saveButton.interactable = false;

        // Yeni eklenen kod sat�r�: Butonun metnini de�i�tirir
        saveButtonText.text = "Saved!";
    }

    public void GoToMainMenu()
    {
        SceneManager.LoadScene("QuizStartScene");
    }
}