using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;
using System.Linq;

public class QuizStartManager : MonoBehaviour
{
    public TextMeshProUGUI scoreboardTextUI;
    // Onay paneline eri�im i�in yeni de�i�ken
    public GameObject confirmationPanel;
    private const string SCOREBOARD_KEY = "QuizScoreboard";

    void Start()
    {
        UpdateScoreboardUI();
    }

    public void StartQuiz()
    {
        SceneManager.LoadScene("QuizGameplayScene");
    }

    // Skorlar� silme i�lemini ba�latan yeni metot
    public void ShowConfirmationPanel()
    {
        confirmationPanel.SetActive(true);
    }

    // Onay paneli "Evet" butonuna bas�ld���nda �al��acak metot
    public void ClearScoreboard()
    {
        PlayerPrefs.DeleteKey(SCOREBOARD_KEY);
        UpdateScoreboardUI();
        // ��lem bittikten sonra paneli gizle
        confirmationPanel.SetActive(false);
    }

    // Onay paneli "Hay�r" butonuna bas�ld���nda �al��acak metot
    public void HideConfirmationPanel()
    {
        confirmationPanel.SetActive(false);
    }

    void UpdateScoreboardUI()
    {
        string scoreboardData = PlayerPrefs.GetString(SCOREBOARD_KEY, "");
        string[] scores = scoreboardData.Split('\n');

        System.Text.StringBuilder sb = new System.Text.StringBuilder();
        for (int i = 0; i < scores.Length && i < 5; i++)
        {
            if (!string.IsNullOrEmpty(scores[i]))
            {
                sb.AppendLine((i + 1) + ". " + scores[i]);
            }
        }
        scoreboardTextUI.text = sb.ToString();
    }
}