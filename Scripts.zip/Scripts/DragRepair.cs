using UnityEngine;
using UnityEngine.UI;

public class DragRepair : MonoBehaviour
{
    private Vector3 dragOffset;
    private bool isDragging = false;
    private Vector3 startPosition;

    public string partName; // Bu de�eri RepairGameManager atayacak.

    private bool canBeDragged = false;

    void Start()
    {
        // `partName` de�eri art�k RepairGameManager taraf�ndan atand��� i�in bu metot sadece canBeDragged de�i�kenini s�f�rlar.
        canBeDragged = false;
    }

    void Update()
    {
        if (RepairGameManager.Instance != null)
        {
            // S�r�klemeye yaln�zca takma a�amas� ba�lad���nda izin ver
            if (RepairGameManager.Instance.isInstallationPhase)
            {
                canBeDragged = true;
            }
        }
    }

    void OnMouseDown()
    {
        if (canBeDragged)
        {
            startPosition = transform.position; // S�r�klemeye ba�lamadan �nce pozisyonu kaydet
            dragOffset = transform.position - GetMouseWorldPosition();
            isDragging = true;
        }
    }

    void OnMouseDrag()
    {
        if (isDragging)
        {
            transform.position = GetMouseWorldPosition() + dragOffset;
        }
    }

    void OnMouseUp()
    {
        if (isDragging)
        {
            isDragging = false;
            HandleDrop();
        }
    }

    Vector3 GetMouseWorldPosition()
    {
        Vector3 mousePosition = Input.mousePosition;
        mousePosition.z = Camera.main.nearClipPlane;
        return Camera.main.ScreenToWorldPoint(mousePosition);
    }

    void HandleDrop()
    {
        Collider2D[] colliders = Physics2D.OverlapPointAll(GetMouseWorldPosition());
        bool isValidDrop = false;

        foreach (Collider2D collider in colliders)
        {
            if (collider.CompareTag("DropZone"))
            {
                if (RepairGameManager.Instance != null)
                {
                    if (RepairGameManager.Instance.CheckPartPlacement(partName))
                    {
                        Destroy(gameObject);
                        isValidDrop = true;
                        break;
                    }
                }
            }
        }

        // E�er ge�erli bir b�rakma noktas� bulunamazsa, par�ay� ba�lang�� konumuna geri d�nd�r
        if (!isValidDrop)
        {
            transform.position = startPosition;
        }
    }
}