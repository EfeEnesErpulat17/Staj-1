using UnityEngine;

public class PanelController : MonoBehaviour
{
    // Kontrol edilecek paneli buraya s�r�kleyin
    public GameObject panelToControl;

    public void OpenPanel()
    {
        // Paneli g�r�n�r yapar
        if (panelToControl != null)
        {
            panelToControl.SetActive(true);
        }
    }

    public void ClosePanel()
    {
        // Paneli g�r�nmez yapar
        if (panelToControl != null)
        {
            panelToControl.SetActive(false);
        }
    }
}