using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Linq;
using TMPro;

public class RepairGameManager : MonoBehaviour
{
    public static RepairGameManager Instance;

    [Header("UI Elemanlar�")]
    public TMP_Text brokenPartText;
    public TMP_Text scoreText;
    public Transform inventoryPanel;
    public Transform buttonsPanel;
    public GameObject gameEndPanel;
    public RepairDropZone droneDropZone;

    [Header("Par�a Prefab'leri ve Butonlar�")]
    public List<GameObject> partPrefabs;
    public List<Button> partButtons;

    [Header("UI Ayarlar�")]
    public float partScale = 0.8f;
    public float inventoryPaddingLeft = 10f;
    public float inventoryPaddingRight = 10f;
    public float inventoryPaddingTop = 10f;
    public float inventoryPaddingBottom = 10f;
    public float inventorySpacing = 10f;
    public Vector2 partColliderSize = new Vector2(100f, 100f); // INSPECTOR'dan ayarlanacak yeni de�er

    public bool isInstallationPhase = false;

    private List<string> removalOrder = new List<string>();
    private List<string> installationOrder = new List<string>();

    private int score = 0;
    private string brokenPart;
    private int currentRemovalStep = 0;
    private int currentInstallationStep = 0;

    private List<string> droneParts = new List<string> { "Motor", "ESC", "FlightController", "Receiver", "Propeller", "Battery" };

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
        StartNewGame();
    }

    public void StartNewGame()
    {
        score = 0;
        UpdateScore(0);

        brokenPart = droneParts[Random.Range(0, droneParts.Count)];
        brokenPartText.text = "Broken Part: " + brokenPart;

        ClearExistingObjects();

        DeterminePartOrders();

        SetupRemovalButtons();

        int brokenPartIndex = droneParts.IndexOf(brokenPart);
        GameObject goodPart = partPrefabs[brokenPartIndex];

        GameObject instantiatedPart = Instantiate(goodPart, inventoryPanel);

        instantiatedPart.GetComponent<DragRepair>().partName = droneParts[brokenPartIndex];

        // Par�an�n g�rsel boyutunu ayarla
        instantiatedPart.transform.localScale = new Vector3(partScale, partScale, 1f);

        // YEN� KISIM: Collider boyutunu da ayarla
        BoxCollider2D collider = instantiatedPart.GetComponent<BoxCollider2D>();
        if (collider != null)
        {
            collider.size = partColliderSize;
        }

        isInstallationPhase = false;
        currentRemovalStep = 0;
        currentInstallationStep = 0;

        HorizontalLayoutGroup hlg = inventoryPanel.GetComponent<HorizontalLayoutGroup>();
        if (hlg != null)
        {
            hlg.padding.left = (int)inventoryPaddingLeft;
            hlg.padding.right = (int)inventoryPaddingRight;
            hlg.padding.top = (int)inventoryPaddingTop;
            hlg.padding.bottom = (int)inventoryPaddingBottom;
            hlg.spacing = inventorySpacing;
        }

        droneDropZone.InitializeSprites();
    }

    private void ClearExistingObjects()
    {
        foreach (Transform child in inventoryPanel)
        {
            Destroy(child.gameObject);
        }
    }

    private void DeterminePartOrders()
    {
        var fullRemovalOrder = droneParts.AsEnumerable().Reverse().ToList();
        int brokenPartIndex = fullRemovalOrder.IndexOf(brokenPart);
        removalOrder = fullRemovalOrder.Take(brokenPartIndex + 1).ToList();
        installationOrder = removalOrder.AsEnumerable().Reverse().ToList();

        Debug.Log("S�kme S�ras�: " + string.Join(", ", removalOrder));
        Debug.Log("Takma S�ras�: " + string.Join(", ", installationOrder));
    }

    private void SetupRemovalButtons()
    {
        for (int i = 0; i < partButtons.Count; i++)
        {
            Button button = partButtons[i];
            button.gameObject.SetActive(true);
            button.onClick.RemoveAllListeners();

            button.interactable = true;

            string partName = droneParts.AsEnumerable().Reverse().ToList()[i];
            button.onClick.AddListener(() => OnPartButtonClick(partName, button));
        }

        SetButtonsPanelInteractivity(true);
    }

    public void OnPartButtonClick(string partName, Button button)
    {
        if (!buttonsPanel.GetComponent<CanvasGroup>().interactable) return;

        if (currentRemovalStep < removalOrder.Count && partName == removalOrder[currentRemovalStep])
        {
            UpdateScore(10);
            droneDropZone.OnPartRemoved();

            button.interactable = false;

            currentRemovalStep++;

            if (partName != brokenPart)
            {
                int partIndex = droneParts.IndexOf(partName);
                if (partIndex >= 0 && partIndex < partPrefabs.Count)
                {
                    GameObject instantiatedPart = Instantiate(partPrefabs[partIndex], inventoryPanel);

                    instantiatedPart.GetComponent<DragRepair>().partName = droneParts[partIndex];

                    // Par�an�n g�rsel boyutunu ayarla
                    instantiatedPart.transform.localScale = new Vector3(partScale, partScale, 1f);

                    // YEN� KISIM: Collider boyutunu da ayarla
                    BoxCollider2D collider = instantiatedPart.GetComponent<BoxCollider2D>();
                    if (collider != null)
                    {
                        collider.size = partColliderSize;
                    }
                }
            }

            if (currentRemovalStep >= removalOrder.Count)
            {
                SetButtonsPanelInteractivity(false);
                isInstallationPhase = true;
            }
        }
        else
        {
            UpdateScore(-5);
        }
    }

    public bool CheckPartPlacement(string partName)
    {
        if (buttonsPanel.GetComponent<CanvasGroup>().interactable)
        {
            Debug.Log("�nce t�m par�alar� s�k!");
            return false;
        }

        if (currentInstallationStep < installationOrder.Count && partName == installationOrder[currentInstallationStep])
        {
            UpdateScore(10);
            currentInstallationStep++;
            droneDropZone.OnPartPlaced();

            if (currentInstallationStep >= installationOrder.Count)
            {
                EndGame();
            }
            return true;
        }
        else
        {
            UpdateScore(-5);
        }
        return false;
    }

    private void SetButtonsPanelInteractivity(bool state)
    {
        var canvasGroup = buttonsPanel.GetComponent<CanvasGroup>();
        if (canvasGroup != null)
        {
            canvasGroup.interactable = state;
            canvasGroup.alpha = state ? 1f : 0.5f;
        }
    }

    public void UpdateScore(int scoreChange)
    {
        score += scoreChange;
        scoreText.text = "Score: " + score;
    }

    private void EndGame()
    {
        PlayerPrefs.SetString("LastGameKey", "RepairHighScores");
        PlayerPrefs.SetInt("LastScore", score);
        SceneManager.LoadScene("ScoreInputScene");

        Debug.Log("Oyun bitti! Puan�n�z: " + score);
    }

    public void RestartGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    public void GoToMainMenu()
    {
        SceneManager.LoadScene("MainMenuScene");
    }
}