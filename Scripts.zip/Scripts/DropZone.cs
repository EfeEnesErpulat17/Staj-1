using UnityEngine;

public class DropZone : MonoBehaviour
{
    // Inspector'da atama yapaca��n, tak�lacak par�alar�n g�rselleri
    public Sprite[] filledSprites;

    // Boyutu ne kadar b�y�tece�ini belirler
    public float scaleFactor = 2.0f;

    private SpriteRenderer spriteRenderer;
    private int currentSpriteIndex = 0;

    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    // Art�k bu metodu GameManager script'i �a��racak
    public void OnItemDropped()
    {
        // E�er g�sterilecek daha fazla g�rsel varsa
        if (currentSpriteIndex < filledSprites.Length && spriteRenderer != null)
        {
            // Dizideki bir sonraki g�rseli atar
            spriteRenderer.sprite = filledSprites[currentSpriteIndex];

            // GameObject'in boyutunu b�y�t
            transform.localScale = new Vector3(scaleFactor, scaleFactor, 1);

            // �ndeksi bir art�r�r
            currentSpriteIndex++;
        }
    }
}