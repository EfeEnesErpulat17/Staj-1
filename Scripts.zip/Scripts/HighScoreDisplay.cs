using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class HighScoreDisplay : MonoBehaviour
{
    public Text assemblyScoreTitle;
    public Text[] assemblyScoreTexts;
    public Text repairScoreTitle;
    public Text[] repairScoreTexts;

    private void OnEnable()
    {
        // Sahne her aktif oldu�unda puanlar� yenilemek i�in Refresh metodunu �a��r
        Refresh();
    }

    public void Refresh()
    {
        string assemblyKey = "AssemblyHighScores";
        string repairKey = "RepairHighScores";

        DisplayScores(assemblyKey, "Drone Assembly Game", assemblyScoreTitle, assemblyScoreTexts);
        DisplayScores(repairKey, "Drone Repair Game", repairScoreTitle, repairScoreTexts);
    }

    private void DisplayScores(string gameKey, string title, Text titleText, Text[] scoreTexts)
    {
        if (titleText != null)
        {
            titleText.text = title;
        }

        List<HighScoreEntry> scores = HighScoreManager.Instance.GetScores(gameKey);

        for (int i = 0; i < scoreTexts.Length; i++)
        {
            if (scoreTexts[i] != null)
            {
                if (i < scores.Count)
                {
                    scoreTexts[i].text = (i + 1) + ". " + scores[i].playerName + " - " + scores[i].score;
                }
                else
                {
                    scoreTexts[i].text = (i + 1) + ". -";
                }
            }
        }
    }
}