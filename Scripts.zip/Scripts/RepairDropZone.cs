using UnityEngine;

public class RepairDropZone : MonoBehaviour
{
    public Sprite[] droneSprites;
    private SpriteRenderer spriteRenderer;
    private int currentSpriteIndex;

    // INSPECTOR'DAN AYARLANACAK BA�LANGI� BOYUTU
    public float initialScale = 1.0f;

    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        // Oyun ba�lad���nda drop zone'un boyutunu ayarla
        transform.localScale = new Vector3(initialScale, initialScale, 1.0f);

        InitializeSprites();
    }

    public void InitializeSprites()
    {
        currentSpriteIndex = droneSprites.Length - 1;
        if (spriteRenderer != null && droneSprites.Length > 0)
        {
            spriteRenderer.sprite = droneSprites[currentSpriteIndex];
        }
    }

    public void OnPartRemoved()
    {
        if (currentSpriteIndex > 0 && spriteRenderer != null)
        {
            currentSpriteIndex--;
            spriteRenderer.sprite = droneSprites[currentSpriteIndex];
        }
    }

    public void OnPartPlaced()
    {
        if (currentSpriteIndex < droneSprites.Length - 1 && spriteRenderer != null)
        {
            currentSpriteIndex++;
            spriteRenderer.sprite = droneSprites[currentSpriteIndex];
        }
    }
}