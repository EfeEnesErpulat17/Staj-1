using UnityEngine;
using UnityEngine.UI;

public class ClearConfirmationDialog : MonoBehaviour
{
    public GameObject confirmationPanel;
    public HighScoreDisplay highScoreDisplay;

    private string gameKeyToClear;

    // "Emin misin?" panelini g�sterir
    public void ShowConfirmation(string gameKey)
    {
        gameKeyToClear = gameKey;
        confirmationPanel.SetActive(true);
    }

    // "Evet" butonuna bas�ld���nda �al���r
    public void OnYesClicked()
    {
        if (HighScoreManager.Instance != null)
        {
            HighScoreManager.Instance.ClearScores(gameKeyToClear);
            highScoreDisplay.Refresh(); // Puan listesini yenile
        }
        HideConfirmation();
    }

    // "Hay�r" butonuna bas�ld���nda �al���r
    public void OnNoClicked()
    {
        HideConfirmation();
    }

    private void HideConfirmation()
    {
        confirmationPanel.SetActive(false);
    }
}