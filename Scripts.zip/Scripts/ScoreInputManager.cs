using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro; // TextMeshPro kullan�yorsan bu k�t�phaneyi ekle

public class ScoreInputManager : MonoBehaviour
{
    public TMP_InputField nameInputField; // Oyuncu ismi i�in
    public Button saveButton;
    public TextMeshProUGUI scoreText; // Puan� g�stermek i�in

    private int lastScore;

    void Start()
    {
        // GameManager'dan kaydetti�imiz skoru al
        lastScore = PlayerPrefs.GetInt("LastScore", 0);
        scoreText.text = "Score: " + lastScore;
    }

    public void SaveScore()
    {
        string playerName = nameInputField.text;
        if (string.IsNullOrEmpty(playerName))
        {
            playerName = "Anonim";
        }

        // Oynanan oyunun anahtar�n� al ve ona g�re puan� kaydet
        string gameKey = PlayerPrefs.GetString("LastGameKey", "AssemblyHighScores");

        if (HighScoreManager.Instance != null)
        {
            HighScoreManager.Instance.AddNewScore(gameKey, playerName, lastScore);

            // Kaydetme i�lemi tamamland�, butonu kilitliyoruz
            saveButton.interactable = false;
            saveButton.GetComponentInChildren<TextMeshProUGUI>().text = "Saved!";
        }
    }

    public void GoToMainMenu()
    {
        SceneManager.LoadScene("MainMenuScene");
    }
}