using UnityEngine;
using System.Collections.Generic;
using System.Linq;

public class HighScoreManager : MonoBehaviour
{
    public static HighScoreManager Instance;

    private const string ASSEMBLY_KEY = "AssemblyHighScores";
    private const string REPAIR_KEY = "RepairHighScores";
    private const int MAX_SCORES = 5;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public List<HighScoreEntry> GetScores(string gameKey)
    {
        string json = PlayerPrefs.GetString(gameKey, "{}");
        if (json == "{}") return new List<HighScoreEntry>();
        return JsonUtility.FromJson<ListWrapper>(json).scores;
    }

    public void AddNewScore(string gameKey, string playerName, int newScore)
    {
        List<HighScoreEntry> scores = GetScores(gameKey);

        HighScoreEntry newEntry = new HighScoreEntry(playerName, newScore);

        // Yeni skoru listenin ba��na ekle.
        scores.Insert(0, newEntry);

        // Skoru en y�ksekten en d����e s�rala.
        // Ayn� puana sahip skorlar aras�nda, listenin en ba��nda olan (yani en yeni) �stte kal�r.
        scores = scores.OrderByDescending(s => s.score).ToList();

        // �lk 5'ten fazla skor varsa fazlal�klar� sil
        if (scores.Count > MAX_SCORES)
        {
            scores.RemoveAt(MAX_SCORES);
        }

        // Skor listesini kaydet
        string json = JsonUtility.ToJson(new ListWrapper { scores = scores });
        PlayerPrefs.SetString(gameKey, json);
        PlayerPrefs.Save();
    }

    public void ClearScores(string gameKey)
    {
        PlayerPrefs.DeleteKey(gameKey);
        PlayerPrefs.Save();
        Debug.Log("Puanlar temizlendi: " + gameKey);
    }

    [System.Serializable]
    private class ListWrapper
    {
        public List<HighScoreEntry> scores;
    }
}