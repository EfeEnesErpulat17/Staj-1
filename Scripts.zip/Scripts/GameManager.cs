using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement; // Sahne ge�i�leri i�in bu k�t�phaneyi ekle

public class GameManager : MonoBehaviour
{
    public enum PartType { None, Motor, ESC, FlightController, Receiver, Propeller, Battery }

    public DropZone droneDropZone;
    public Text scoreText;

    private int score = 0;
    private int currentStep = 0;

    private PartType[] assemblyOrder = {
        PartType.Motor,
        PartType.ESC,
        PartType.FlightController,
        PartType.Receiver,
        PartType.Propeller,
        PartType.Battery
    };

    void Start()
    {
        UpdateScoreText();
    }

    public bool CheckPartPlacement(string partName)
    {
        if (currentStep >= assemblyOrder.Length)
        {
            return false;
        }

        PartType droppedPart;
        if (System.Enum.TryParse(partName, out droppedPart))
        {
            if (droppedPart == assemblyOrder[currentStep])
            {
                score += 10;
                currentStep++;
                droneDropZone.OnItemDropped();
                UpdateScoreText();

                // Par�a do�ruysa, oyunun bitip bitmedi�ini kontrol et
                CheckIfGameOver();

                return true;
            }
        }

        score -= 5;
        UpdateScoreText();
        return false;
    }

    private void CheckIfGameOver()
    {
        // E�er t�m par�alar do�ru �ekilde yerle�tirildiyse oyun biter
        if (currentStep >= assemblyOrder.Length)
        {
            // Hangi oyunun puan�n�n kaydedilece�ini belirtir
            PlayerPrefs.SetString("LastGameKey", "AssemblyHighScores");

            // Puan� ge�ici olarak kaydet
            PlayerPrefs.SetInt("LastScore", score);

            // Oyun sonu sahnesini y�kle
            SceneManager.LoadScene("ScoreInputScene");
        }
    }

    private void UpdateScoreText()
    {
        if (scoreText != null)
        {
            scoreText.text = "Score: " + score;
        }
    }
}