using UnityEngine;

public class Drag : MonoBehaviour
{
    // Par�an�n ad�n� Inspector'dan gireceksiniz (�rnek: "Motor", "ESC")
    public string partName;

    private bool isDragging = false;
    private Vector3 offset;
    private Vector3 originalPosition;
    private GameManager gameManager;
    private Rigidbody2D rb;

    void Start()
    {
        // GameManager script'ine eri�im
        gameManager = FindFirstObjectByType<GameManager>();

        // Rigidbody2D bile�enine eri�im
        rb = GetComponent<Rigidbody2D>();
    }

    void OnMouseDown()
    {
        isDragging = true;
        originalPosition = transform.position;
        offset = transform.position - GetMouseWorldPosition();

        // Art�k burada Body Type'� de�i�tirmeye gerek yok, ��nk� Inspector'da Kinematic yapt�k.
    }

    void OnMouseDrag()
    {
        if (isDragging)
        {
            transform.position = GetMouseWorldPosition() + offset;
        }
    }

    void OnMouseUp()
    {
        isDragging = false;

        // Art�k burada Body Type'� de�i�tirmeye gerek yok.

        Collider2D[] colliders = Physics2D.OverlapPointAll(transform.position);
        Collider2D dropZoneCollider = null;

        foreach (Collider2D collider in colliders)
        {
            if (collider.CompareTag("MotorDropZone"))
            {
                dropZoneCollider = collider;
                break;
            }
        }

        if (dropZoneCollider != null && gameManager != null)
        {
            bool isCorrect = gameManager.CheckPartPlacement(partName);

            if (isCorrect)
            {
                Destroy(gameObject);
            }
            else
            {
                transform.position = originalPosition;
            }
        }
        else
        {
            transform.position = originalPosition;
        }
    }

    private Vector3 GetMouseWorldPosition()
    {
        Vector3 mousePoint = Input.mousePosition;
        mousePoint.z = Camera.main.nearClipPlane;
        return Camera.main.ScreenToWorldPoint(mousePoint);
    }
}