using UnityEngine;
using UnityEngine.UI;

public class ProgressiveDropZone : MonoBehaviour
{
    public Image progressiveImage;
    public float currentProgress = 0f;
    public float maxProgress = 1f;

    void Start()
    {
        // Ba�lang��ta bar� s�f�rla
        ResetProgress();
    }

    // �lerleme �ubu�unun doluluk oran�n� art�r�r
    public void AddProgress(float amount)
    {
        currentProgress += amount;
        currentProgress = Mathf.Clamp(currentProgress, 0f, maxProgress);
        UpdateVisual();
    }

    // �lerleme �ubu�unu tamamen s�f�rlar
    public void ResetProgress()
    {
        currentProgress = 0f;
        UpdateVisual();
    }

    // �lerleme �ubu�unun g�rselini g�nceller
    private void UpdateVisual()
    {
        if (progressiveImage != null)
        {
            progressiveImage.fillAmount = currentProgress / maxProgress;
        }
    }
}