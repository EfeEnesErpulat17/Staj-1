using UnityEngine;

public class QuitGame : MonoBehaviour
{
    public void Quit()
    {
        // Unity Editor'da �al���rken bu komut oyunu durdurur.
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
            // Ger�ek bir uygulamada bu komut oyunu kapat�r.
            Application.Quit();
#endif
    }
}