using UnityEngine;

public class AspectRatioEnforcer : MonoBehaviour
{
    // Hedeflenen en boy oran� (�rne�in 3:2 i�in 1.5f, 16:9 i�in 1.777f)
    public float targetAspect = 1.7f;

    Camera mainCamera;

    void Awake()
    {
        mainCamera = GetComponent<Camera>();
        if (mainCamera == null)
        {
            Debug.LogError("Bu script sadece bir kamera objesine eklenmelidir.", this);
            return;
        }

        ResizeCameraView();
    }

    void Update()
    {
        // Gerekirse ekran boyutu de�i�ti�inde otomatik ayar yapmak i�in
        // Bu kod, daha do�ru sonu�lar i�in Update yerine ResizeCameraView metodunu �a��rabilir.
        // �rne�in: ResizeCameraView();
    }

    // Kameran�n g�r�� alan�n� ayarlar
    void ResizeCameraView()
    {
        float currentAspect = (float)Screen.width / Screen.height;
        float ratio = currentAspect / targetAspect;

        // Dikey �ubuklar (Pillarbox) i�in
        if (ratio < 1.0f)
        {
            mainCamera.rect = new Rect((1.0f - ratio) / 2.0f, 0, ratio, 1.0f);
        }
        // Yatay �ubuklar (Letterbox) i�in
        else
        {
            float newRatio = 1.0f / ratio;
            mainCamera.rect = new Rect(0, (1.0f - newRatio) / 2.0f, 1.0f, newRatio);
        }
    }
}